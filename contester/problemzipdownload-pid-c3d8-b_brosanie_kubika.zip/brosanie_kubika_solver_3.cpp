#include <iostream>
#include <vector>
#include <algorithm>
#include <stdio.h>

using namespace std;

int N, Q;

double mas [510][3100];

int main()
{
  cin >> N >> Q;
  mas[0][0] = 1.0;
  for (int i = 1; i <= N; ++i)
  {
    for (int j = 0; j <= Q; ++j)
    {
      double sum = 0.0;
      for (int k = 1; k <= 6; ++k)
      {
        if (j - k >= 0)
        {
          sum += mas[i-1][j-k];
        }
      }
      sum /= 6.0;
      mas[i][j] = sum;
    }
  }
  printf("%ld\n", mas[N][Q]);
  return 0;
}
